#' Square
#'
#' This function is used to square a number or vector .
#' @param number, or vector, given in a numeric format
#' @keywords square
#' @export
#' @examples
#' Square()


Square = function(number = NULL){
  number^2
}
